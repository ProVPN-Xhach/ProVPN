module.exports = async ({ lunatix, msg, sender, lunaticreply, isAdmin }) => {
    if (!isAdmin) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");

    try {
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo
        const quotedMsg = contextInfo?.quotedMessage
        const quotedId = contextInfo?.stanzaId
        const quotedSender = contextInfo?.participant
        const remoteJid = msg.key.remoteJid

        if (!quotedMsg || !quotedId || !quotedSender) {
            return lunaticreply("⚠ Balas pesan yang ingin dihapus dengan perintah ini.")
        }

        await lunatix.sendMessage(remoteJid, {
            delete: {
                remoteJid,
                fromMe: false,
                id: quotedId,
                participant: quotedSender
            }
        })

    } catch (error) {
        console.error("❌ Gagal hapus pesan:", error)
        lunaticreply("❌ Gagal menghapus pesan. Pastikan bot dan kamu adalah admin grup.")
    }
}

module.exports = async ({ lunatix, msg, sender, isGroup, isAdmin, lunaticreply, args }) => {
    if (!isGroup) return lunaticreply('❌ Perintah ini hanya untuk grup.');
    if (!isAdmin) return lunaticreply('⚠️ Perintah ini hanya bisa digunakan oleh admin.');

    const from = msg.key.remoteJid; // <- ini ID grup yang benar
    const groupMetadata = await lunatix.groupMetadata(from);
    const participants = groupMetadata.participants;

    let target;

    // ✅ PRIORITAS: Balas pesan
    if (msg.message.extendedTextMessage?.contextInfo?.participant) {
        target = msg.message.extendedTextMessage.contextInfo.participant;
    }
    // ✅ Kalau mention
    else if (msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // ✅ Kalau input nomor manual
    else if (args[0]) {
        const nomor = args[0].replace(/[^0-9]/g, '');
        target = `${nomor}@s.whatsapp.net`;
    } else {
        return lunaticreply('⚠️ Tag, balas pesan, atau ketik nomor user yang ingin dikeluarkan.');
    }

    // Cek apakah user ada di grup
    const isMember = participants.some(p => p.id === target);
    if (!isMember) return lunaticreply('❌ User tidak ditemukan di grup ini.');

    // Kick
    try {
        await lunatix.groupParticipantsUpdate(from, [target], 'remove');
        lunaticreply('✅ Berhasil mengeluarkan user dari grup.');
    } catch (err) {
        console.error(err);
        lunaticreply('❌ Gagal mengeluarkan user. Pastikan bot adalah admin grup!');
    }
};

const fs = require('fs');
const path = require('path');

module.exports = async ({ isOwner, q, isAdmin, lunaticreply }) => {

    // Cegah akses jika bukan admin dan bukan owner
    if (!isAdmin && !isOwner) {
        return lunaticreply("❌ Hanya Admin atau Owner yang bisa pakai fitur ini!");
    }

    // Ambil prefix dari prefix.json
    let prefix = '!';
    try {
        const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
        prefix = pf.prefix || '!';
    } catch (err) {
        console.error("Gagal membaca prefix.json:", err.message);
    }

    // Validasi input prefix
    if (!q) {
        return lunaticreply(`⚠️ Masukkan prefix baru!\nContoh: ${prefix}set $`);
    }

    const newPrefix = q.trim();

    // Simpan prefix baru
    try {
        fs.writeFileSync(
            path.join(__dirname, '../avars/prefix.json'),
            JSON.stringify({ prefix: newPrefix }, null, 2)
        );
        lunaticreply(`✅ Prefix berhasil diubah jadi: *${newPrefix}*`);
    } catch (err) {
        lunaticreply("❌ Gagal menyimpan prefix baru.");
        console.error("Gagal menulis prefix.json:", err.message);
    }
};
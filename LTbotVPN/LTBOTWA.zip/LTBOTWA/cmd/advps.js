const fs = require('fs');
const path = './avars/vpsdata.json';
module.exports = async ({ isAdmin, isOwner, lunaticreply, args, sender }) => {
if (!isOwner && !isAdmin) return lunaticreply('❌ Fitur ini hanya untuk *Owner Bot*!');
// Prefix dinamis
let prefix = '!';
try {
const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
prefix = pf.prefix || '!';
} catch {}
const [nama, ip, pass] = args;
if (!nama || !ip || !pass) {
return lunaticreply(`*Contoh:*\n${prefix}advps namaVPS ipVPS pwVPS`);
}
// Buat file jika belum ada
if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}, null, 2));
const db = JSON.parse(fs.readFileSync(path));
db[nama] = { ip, pass };
fs.writeFileSync(path, JSON.stringify(db, null, 2));
return lunaticreply(`✅ VPS *${nama}* berhasil disimpan ke database!\n\n🖥 IP      : ${ip}\n🔐 Pass   : ${pass}`);
};
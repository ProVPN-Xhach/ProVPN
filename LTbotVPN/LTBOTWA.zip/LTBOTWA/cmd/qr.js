// cmd/qriss.js

const fs = require('fs');
const path = require('path');

module.exports = async ({ lunatix, msg }) => {
  const qrPath = path.resolve(__dirname, '../image/QR.jpeg');

  if (!fs.existsSync(qrPath)) {
    return lunatix.sendMessage(msg.key.remoteJid, {
      text: '❌ Gambar QRIS tidak ditemukan!',
    }, { quoted: msg });
  }

  await lunatix.sendMessage(msg.key.remoteJid, {
    image: fs.readFileSync(qrPath),
    caption: '*📌 QRIS Pembayaran*\n\nSilakan scan kode QR di atas untuk melakukan pembayaran.',
  }, { quoted: msg });
};

const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = async ({ lunatix, msg, sender, lunaticreply, q }) => {
  // Ambil prefix dari prefix.json
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}
  // BATAS AMBIL GLOBAL PREFIX 
  
    if (!q) return lunaticreply("*EXAMPLE:* ${prefix}viewcode https://example.com");

    if (!/^https?:\/\//.test(q)) {
        return lunaticreply("❌ URL harus dimulai dengan http:// atau https://");
    }

    try {
        const response = await axios.get(q, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });

        const htmlContent = response.data;

        // Simpan file HTML sementara
        const filePath = path.join(__dirname, '../tmp/viewcode.html');
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, htmlContent);

        // Kirim file ke WhatsApp
        await lunatix.sendMessage(sender, {
            document: fs.readFileSync(filePath),
            fileName: 'viewcode.html',
            mimetype: 'text/html',
            caption: `📄 Source code dari: ${q}`
        }, { quoted: msg });

        // Hapus file setelah 10 detik
        setTimeout(() => {
            fs.unlinkSync(filePath);
        }, 10_000);

    } catch (error) {
        console.error("❌ ViewCode Error:", error);
        lunaticreply("❌ Gagal mengambil source code. Pastikan URL valid dan bisa diakses.");
    }
};
